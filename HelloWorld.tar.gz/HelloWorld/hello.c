#include<stdio.h>
int main(){
	printf("Hey T-Systems\n");
	printf("Welcome to RDK Lab\n");
}
